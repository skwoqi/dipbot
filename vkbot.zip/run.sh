#!/bin/sh
set -e

python -m pip install --no-cache-dir -r requirements.txt
python main.py
