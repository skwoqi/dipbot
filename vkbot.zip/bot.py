import asyncio
import json
import logging
import re
from datetime import datetime
from typing import Any

from vkbottle import BaseStateGroup, Bot, CtxStorage, Keyboard, KeyboardButtonColor, Text
from vkbottle import PhotoMessageUploader

from config import ADMIN_PEER_ID, DB_PATH, GROUP_ID, VK_BOT_TOKEN
from db import Database

logging.basicConfig(level=logging.INFO)

db = Database(DB_PATH)
bot = Bot(token=VK_BOT_TOKEN)
uploader = PhotoMessageUploader(bot.api)
storage = CtxStorage()

PHONE_RE = re.compile(r"^[+]?[0-9()\-\s]{10,20}$")

EQUIPMENT_LABELS = {
    "excavator": "Экскаватор-погрузчик",
    "crane": "Автокран",
    "dump": "Самосвал",
}
EQUIPMENT_PRICES = {"excavator": 3500, "crane": 3500, "dump": 3000}
ATTACHMENTS = [("bucket", "Ковш"), ("hammer", "Гидромолот"), ("drill", "Ямобур")]
ATTACHMENT_LABELS = dict(ATTACHMENTS)

EXCAVATOR_PHOTOS = [r"C:\codex\фото\traktor.jpg"]
CRANE_PHOTOS = [r"C:\codex\фото\kran_2.jpg"]
DUMP_PHOTOS = [r"C:\codex\фото\samosval 3.jpg"]


class OrderStates(BaseStateGroup):
    MAIN_MENU = "main_menu"
    CATALOG_MENU = "catalog_menu"
    EXCAVATOR_ATTACHMENT = "excavator_attachment"
    SHOW_EQUIPMENT_EXCAVATOR = "show_equipment_excavator"
    SHOW_EQUIPMENT_CRANE = "show_equipment_crane"
    SHOW_EQUIPMENT_DUMP = "show_equipment_dump"
    SHOW_PRICES = "show_prices"
    ORDER_NAME = "order_name"
    ORDER_PHONE = "order_phone"
    ORDER_EQUIPMENT_TYPE = "order_equipment_type"
    ORDER_EXCAVATOR_ATTACHMENT = "order_excavator_attachment"
    ORDER_HOURS = "order_hours"
    ORDER_DATE = "order_date"
    ORDER_FINAL = "order_final"
    ORDER_SAVED = "order_saved"
    WAITING_FOR_CALC_DETAILS = "waiting_for_calc_details"
    SHOW_CONTACTS = "show_contacts"


def get_state(user_id: int) -> str:
    return storage.get(f"state:{user_id}") or OrderStates.MAIN_MENU


def set_state(user_id: int, state: str) -> None:
    storage.set(f"state:{user_id}", state)


def get_data(user_id: int) -> dict[str, Any]:
    return storage.get(f"data:{user_id}") or {}


def update_data(user_id: int, **kwargs: Any) -> dict[str, Any]:
    data = get_data(user_id)
    data.update(kwargs)
    storage.set(f"data:{user_id}", data)
    return data


def clear_data(user_id: int) -> None:
    storage.set(f"data:{user_id}", {})


def is_admin(user_id: int) -> bool:
    return ADMIN_PEER_ID != 0 and user_id == ADMIN_PEER_ID


def parse_payload(raw_payload: str | None) -> dict[str, Any]:
    if not raw_payload:
        return {}
    try:
        return json.loads(raw_payload)
    except json.JSONDecodeError:
        return {}


def is_start_text(text: str) -> bool:
    t = text.strip().lower()
    return t in {"/start", "start", "начать", "start bot", "старт"}


def attachments_to_text(keys: list[str] | None) -> str:
    if not keys:
        return "не требуется"
    return ", ".join(ATTACHMENT_LABELS.get(key, key) for key in keys)


def order_summary(data: dict[str, Any]) -> str:
    return (
        "📋 ВАША ЗАЯВКА:\n"
        f"Имя: {data.get('user_name', '-')}\n"
        f"Телефон: {data.get('user_phone', '-')}\n"
        f"Техника: {EQUIPMENT_LABELS.get(data.get('equipment_type', ''), '-')}\n"
        f"Навесное: {attachments_to_text(data.get('attachments'))}\n"
        f"Часов: {data.get('hours', '-')}\n"
        f"Дата: {data.get('date', '-')}\n\n"
        "✅ Подтверждаете заявку?"
    )


def main_menu_kb() -> str:
    kb = Keyboard(one_time=False, inline=False)
    kb.add(Text("🚜 Каталог техники"))
    kb.add(Text("💰 Цены и тарифы"))
    kb.row()
    kb.add(Text("📝 Оставить заявку"))
    kb.add(Text("📞 Контакты"))
    return kb.get_json()


def catalog_kb() -> str:
    kb = Keyboard(one_time=False, inline=True)
    kb.add(Text("🚧 Экскаваторы-погрузчики", payload={"cmd": "cat_excavator"}), color=KeyboardButtonColor.PRIMARY)
    kb.row()
    kb.add(Text("🏭 Автокраны", payload={"cmd": "cat_crane"}), color=KeyboardButtonColor.PRIMARY)
    kb.row()
    kb.add(Text("🚛 Самосвалы", payload={"cmd": "cat_dump"}), color=KeyboardButtonColor.PRIMARY)
    return kb.get_json()


def attachment_checkbox_kb(selected: list[str], prefix: str) -> str:
    kb = Keyboard(one_time=False, inline=True)
    for key, label in ATTACHMENTS:
        mark = "✅" if key in selected else "⬜"
        kb.add(Text(f"{mark} {label}", payload={"cmd": prefix, "action": "toggle", "value": key}))
        kb.row()
    kb.add(Text("✅ Готово", payload={"cmd": prefix, "action": "done"}), color=KeyboardButtonColor.POSITIVE)
    return kb.get_json()


def one_button_kb(text: str, payload: dict[str, Any], color: KeyboardButtonColor = KeyboardButtonColor.PRIMARY) -> str:
    kb = Keyboard(one_time=False, inline=True)
    kb.add(Text(text, payload=payload), color=color)
    return kb.get_json()


def equipment_choice_kb() -> str:
    kb = Keyboard(one_time=False, inline=True)
    kb.add(Text("🚧 Экскаватор-погрузчик", payload={"cmd": "order_eq", "value": "excavator"}))
    kb.row()
    kb.add(Text("🏭 Автокран", payload={"cmd": "order_eq", "value": "crane"}))
    kb.row()
    kb.add(Text("🚛 Самосвал", payload={"cmd": "order_eq", "value": "dump"}))
    return kb.get_json()


def order_final_kb() -> str:
    kb = Keyboard(one_time=False, inline=True)
    kb.add(Text("✅ Да", payload={"cmd": "order_confirm"}), color=KeyboardButtonColor.POSITIVE)
    kb.row()
    kb.add(Text("❌ Нет", payload={"cmd": "order_cancel"}), color=KeyboardButtonColor.NEGATIVE)
    kb.row()
    kb.add(Text("✏️ Редактировать", payload={"cmd": "order_edit"}), color=KeyboardButtonColor.SECONDARY)
    return kb.get_json()


async def upload_attachments(paths: list[str]) -> str:
    if not paths:
        return ""
    uploaded = []
    for path in paths:
        attachment = await uploader.upload(path)
        uploaded.append(attachment)
    return ",".join(uploaded)


async def send_main_menu(peer_id: int, user_id: int) -> None:
    set_state(user_id, OrderStates.MAIN_MENU)
    await bot.api.messages.send(
        peer_id=peer_id,
        random_id=0,
        message="Добро пожаловать! 🚜 Аренда спецтехники в вашем городе.",
        keyboard=main_menu_kb(),
    )


async def send_catalog(peer_id: int, user_id: int) -> None:
    set_state(user_id, OrderStates.CATALOG_MENU)
    await bot.api.messages.send(
        peer_id=peer_id,
        random_id=0,
        message="Выберите категорию техники:",
        keyboard=catalog_kb(),
    )


async def send_prices(peer_id: int, user_id: int) -> None:
    set_state(user_id, OrderStates.SHOW_PRICES)
    text = (
        "💰 Цены (почасовая оплата):\n"
        "- Экскаватор-погрузчик: 3500 руб/час\n"
        "- Автокран: 3500 руб/час\n"
        "- Самосвал: 3000 руб/час"
    )
    kb = Keyboard(one_time=False, inline=True)
    kb.add(Text("🧮 Рассчитать стоимость", payload={"cmd": "calc"}))
    kb.row()
    kb.add(Text("📝 Заказать", payload={"cmd": "order"}))
    await bot.api.messages.send(peer_id=peer_id, random_id=0, message=text, keyboard=kb.get_json())


async def send_contacts(peer_id: int, user_id: int) -> None:
    set_state(user_id, OrderStates.SHOW_CONTACTS)
    await bot.api.messages.send(
        peer_id=peer_id,
        random_id=0,
        message=(
            "📞 КОНТАКТЫ:\n"
            "Телефон: +7 (XXX) XXX-XX-XX\n"
            "Telegram: @manager\n"
            "Адрес: ул. Строителей, 15\n\n"
            "Режим работы: 24/7"
        ),
        keyboard=one_button_kb("◀️ Назад", {"cmd": "back_main"}),
    )


async def start_order(peer_id: int, user_id: int, preset_equipment: str | None = None, preset_attachments: list[str] | None = None) -> None:
    set_state(user_id, OrderStates.ORDER_NAME)
    clear_data(user_id)
    update_data(
        user_id,
        user_id=user_id,
        attachments=preset_attachments or [],
        equipment_type=preset_equipment,
    )
    await bot.api.messages.send(peer_id=peer_id, random_id=0, message="Введите ваше имя:")


async def send_equipment_card(peer_id: int, user_id: int, equipment_key: str, attachments: list[str] | None = None) -> None:
    if equipment_key == "excavator":
        set_state(user_id, OrderStates.SHOW_EQUIPMENT_EXCAVATOR)
        photo = await upload_attachments(EXCAVATOR_PHOTOS)
        caption = (
            "Экскаватор-погрузчик Hidromek HMK 102S, 2022 г.в.\n"
            f"Выбранное навесное: {attachments_to_text(attachments)}"
        )
    elif equipment_key == "crane":
        set_state(user_id, OrderStates.SHOW_EQUIPMENT_CRANE)
        photo = await upload_attachments(CRANE_PHOTOS)
        caption = "Автокран вездеход «Клинцы» 25 т. 28 м."
    else:
        set_state(user_id, OrderStates.SHOW_EQUIPMENT_DUMP)
        photo = await upload_attachments(DUMP_PHOTOS)
        caption = "Самосвал Shacman X3000 30 тонн"
    await bot.api.messages.send(
        peer_id=peer_id,
        random_id=0,
        message=caption,
        attachment=photo,
        keyboard=one_button_kb("🔧 Заказать эту технику", {"cmd": "order_this"}),
    )


@bot.on.private_message()
async def handle_all(message) -> None:
    if not message.from_id or message.from_id < 0:
        return
    user_id = message.from_id
    peer_id = message.peer_id
    text = (message.text or "").strip()
    payload = parse_payload(message.payload)
    cmd = payload.get("cmd")

    db.save_user(user_id, None, f"id{user_id}")
    state = get_state(user_id)

    if is_start_text(text) or cmd == "start":
        await send_main_menu(peer_id, user_id)
        return
    if text.startswith("/help"):
        await bot.api.messages.send(
            peer_id=peer_id,
            random_id=0,
            message=(
                "/start - Главное меню\n"
                "/status <номер_заявки> - Проверить статус\n"
                "/help - Помощь\n"
                "/admin - Админ-панель (скрыто)"
            ),
        )
        return
    if text.startswith("/status"):
        parts = text.split(maxsplit=1)
        if len(parts) < 2 or not parts[1].isdigit():
            await bot.api.messages.send(peer_id=peer_id, random_id=0, message="Укажите номер заявки: /status 123")
            return
        order = db.get_order(int(parts[1]))
        if not order:
            await bot.api.messages.send(peer_id=peer_id, random_id=0, message="Заявка не найдена.")
            return
        await bot.api.messages.send(
            peer_id=peer_id,
            random_id=0,
            message=(
                f"Заявка №{order['id']}\n"
                f"Статус: {order['status']}\n"
                f"Техника: {EQUIPMENT_LABELS.get(order['equipment_type'], order['equipment_type'])}\n"
                f"Дата: {order['date']}"
            ),
        )
        return
    if text.startswith("/admin"):
        if text.startswith("/admin_stats") or text.startswith("/admin_list") or text.startswith("/admin_view") or text.startswith("/admin_confirm") or text.startswith("/admin_done") or text.startswith("/admin_delete"):
            pass
        else:
            await bot.api.messages.send(
                peer_id=peer_id,
                random_id=0,
                message=(
                    "Админ-команды:\n"
                    "/admin_stats\n/admin_list\n/admin_view <id>\n"
                    "/admin_confirm <id>\n/admin_done <id>\n/admin_delete <id>"
                ),
            )
            return

    if text.startswith("/admin_stats"):
        if not is_admin(user_id):
            return
        stats = db.orders_stats()
        await bot.api.messages.send(
            peer_id=peer_id,
            random_id=0,
            message=(
                "📊 Статистика заявок:\n"
                f"Новых: {stats['new']}\n"
                f"Подтверждённых: {stats['confirmed']}\n"
                f"Выполненных: {stats['completed']}\n"
                f"Отменённых: {stats['cancelled']}\n"
                f"Всего: {stats['total']}"
            ),
        )
        db.log_admin_action(user_id, "admin_stats")
        return

    if text.startswith("/admin_list"):
        if not is_admin(user_id):
            return
        items = db.list_orders()
        if not items:
            await bot.api.messages.send(peer_id=peer_id, random_id=0, message="Заявок пока нет.")
            return
        lines = ["📋 Список заявок:"]
        for item in items:
            lines.append(
                f"#{item['id']} | {item['user_name']} | {EQUIPMENT_LABELS.get(item['equipment_type'], item['equipment_type'])} | {item['status']} | {item['created_at']}"
            )
        await bot.api.messages.send(peer_id=peer_id, random_id=0, message="\n".join(lines))
        db.log_admin_action(user_id, "admin_list")
        return

    if text.startswith("/admin_view"):
        if not is_admin(user_id):
            return
        parts = text.split(maxsplit=1)
        if len(parts) < 2 or not parts[1].isdigit():
            await bot.api.messages.send(peer_id=peer_id, random_id=0, message="Использование: /admin_view <id>")
            return
        order = db.get_order(int(parts[1]))
        if not order:
            await bot.api.messages.send(peer_id=peer_id, random_id=0, message="Заявка не найдена.")
            return
        await bot.api.messages.send(
            peer_id=peer_id,
            random_id=0,
            message=(
                f"Заявка №{order['id']}\n"
                f"Имя: {order['user_name']}\n"
                f"Телефон: {order['user_phone']}\n"
                f"Техника: {EQUIPMENT_LABELS.get(order['equipment_type'], order['equipment_type'])}\n"
                f"Навесное: {attachments_to_text(order.get('attachments'))}\n"
                f"Часы: {order['hours']}\n"
                f"Дата: {order['date']}\n"
                f"Статус: {order['status']}"
            ),
        )
        db.log_admin_action(user_id, "admin_view", order["id"])
        return

    if text.startswith("/admin_confirm") or text.startswith("/admin_done") or text.startswith("/admin_delete"):
        if not is_admin(user_id):
            return
        parts = text.split(maxsplit=1)
        if len(parts) < 2 or not parts[1].isdigit():
            await bot.api.messages.send(peer_id=peer_id, random_id=0, message="Нужно указать id, например: /admin_confirm 1")
            return
        order_id = int(parts[1])
        if text.startswith("/admin_delete"):
            ok = db.delete_order(order_id)
            action = "admin_delete"
            result = f"Заявка #{order_id} удалена." if ok else "Заявка не найдена."
        else:
            new_status = "confirmed" if text.startswith("/admin_confirm") else "completed"
            ok = db.update_order_status(order_id, new_status)
            action = "admin_confirm" if new_status == "confirmed" else "admin_done"
            result = f"Заявка #{order_id}: статус -> {new_status}" if ok else "Заявка не найдена."
        await bot.api.messages.send(peer_id=peer_id, random_id=0, message=result)
        if ok:
            db.log_admin_action(user_id, action, order_id)
        return

    if cmd == "back_main":
        await send_main_menu(peer_id, user_id)
        return
    if cmd == "cat_excavator":
        set_state(user_id, OrderStates.EXCAVATOR_ATTACHMENT)
        selected = get_data(user_id).get("catalog_attachments", [])
        await bot.api.messages.send(
            peer_id=peer_id,
            random_id=0,
            message="Какое навесное оборудование вам нужно? (можно выбрать несколько)",
            keyboard=attachment_checkbox_kb(selected, "cat_attach"),
        )
        return
    if cmd == "cat_crane":
        update_data(user_id, catalog_equipment="crane")
        await send_equipment_card(peer_id, user_id, "crane")
        return
    if cmd == "cat_dump":
        update_data(user_id, catalog_equipment="dump")
        await send_equipment_card(peer_id, user_id, "dump")
        return
    if cmd == "cat_attach":
        selected = get_data(user_id).get("catalog_attachments", [])
        action = payload.get("action")
        value = payload.get("value")
        if action == "toggle" and value:
            if value in selected:
                selected.remove(value)
            else:
                selected.append(value)
            update_data(user_id, catalog_attachments=selected)
            await bot.api.messages.send(
                peer_id=peer_id,
                random_id=0,
                message=f"Выбрано: {attachments_to_text(selected)}",
                keyboard=attachment_checkbox_kb(selected, "cat_attach"),
            )
            return
        if action == "done":
            update_data(user_id, catalog_equipment="excavator", catalog_attachments=selected)
            await send_equipment_card(peer_id, user_id, "excavator", selected)
            return
    if cmd == "order_this":
        data = get_data(user_id)
        await start_order(
            peer_id,
            user_id,
            preset_equipment=data.get("catalog_equipment"),
            preset_attachments=data.get("catalog_attachments", []),
        )
        return
    if cmd == "calc":
        set_state(user_id, OrderStates.WAITING_FOR_CALC_DETAILS)
        await bot.api.messages.send(peer_id=peer_id, random_id=0, message='Какая техника и на сколько часов? Пример: "Экскаватор 5 часов"')
        return
    if cmd == "order":
        await start_order(peer_id, user_id)
        return
    if cmd == "from_calc_order":
        set_state(user_id, OrderStates.ORDER_EQUIPMENT_TYPE)
        await bot.api.messages.send(peer_id=peer_id, random_id=0, message="Какую технику нужно арендовать?", keyboard=equipment_choice_kb())
        return
    if cmd == "order_eq":
        key = payload.get("value")
        update_data(user_id, equipment_type=key, attachments=[])
        if key == "excavator":
            set_state(user_id, OrderStates.ORDER_EXCAVATOR_ATTACHMENT)
            await bot.api.messages.send(
                peer_id=peer_id,
                random_id=0,
                message="Какое навесное оборудование нужно? (можно выбрать несколько)",
                keyboard=attachment_checkbox_kb([], "order_attach"),
            )
            return
        set_state(user_id, OrderStates.ORDER_HOURS)
        await bot.api.messages.send(peer_id=peer_id, random_id=0, message="На сколько часов нужна техника?")
        return
    if cmd == "order_attach":
        selected = get_data(user_id).get("attachments", [])
        action = payload.get("action")
        value = payload.get("value")
        if action == "toggle" and value:
            if value in selected:
                selected.remove(value)
            else:
                selected.append(value)
            update_data(user_id, attachments=selected)
            await bot.api.messages.send(
                peer_id=peer_id,
                random_id=0,
                message=f"Выбрано: {attachments_to_text(selected)}",
                keyboard=attachment_checkbox_kb(selected, "order_attach"),
            )
            return
        if action == "done":
            set_state(user_id, OrderStates.ORDER_HOURS)
            await bot.api.messages.send(peer_id=peer_id, random_id=0, message="На сколько часов нужна техника?")
            return
    if cmd == "order_edit":
        await start_order(peer_id, user_id)
        return
    if cmd == "order_cancel":
        clear_data(user_id)
        await send_main_menu(peer_id, user_id)
        return
    if cmd == "order_confirm":
        data = get_data(user_id)
        order_id = db.create_order(data)
        set_state(user_id, OrderStates.ORDER_SAVED)
        await bot.api.messages.send(
            peer_id=peer_id,
            random_id=0,
            message=(
                f"✅ ЗАЯВКА №{order_id} ПРИНЯТА!\n\n"
                "Мы свяжемся с вами в течение 15 минут\n\n"
                f"Проверить статус: /status {order_id}"
            ),
        )
        if ADMIN_PEER_ID:
            await bot.api.messages.send(
                peer_id=ADMIN_PEER_ID,
                random_id=0,
                message=(
                    f"Новая заявка №{order_id}\n"
                    f"Имя: {data.get('user_name')}\n"
                    f"Телефон: {data.get('user_phone')}\n"
                    f"Техника: {EQUIPMENT_LABELS.get(data.get('equipment_type', ''), '-')}\n"
                    f"Навесное: {attachments_to_text(data.get('attachments'))}\n"
                    f"Часы: {data.get('hours')}\n"
                    f"Дата: {data.get('date')}"
                ),
            )
        await asyncio.sleep(5)
        clear_data(user_id)
        await send_main_menu(peer_id, user_id)
        return

    if text == "🚜 Каталог техники":
        await send_catalog(peer_id, user_id)
        return
    if text == "💰 Цены и тарифы":
        await send_prices(peer_id, user_id)
        return
    if text == "📝 Оставить заявку":
        await start_order(peer_id, user_id)
        return
    if text == "📞 Контакты":
        await send_contacts(peer_id, user_id)
        return

    if state == OrderStates.WAITING_FOR_CALC_DETAILS:
        lower = text.lower()
        match = re.search(r"(\d+)", lower)
        hours = int(match.group(1)) if match else 1
        eq = "excavator"
        if "кран" in lower:
            eq = "crane"
        elif "самосвал" in lower:
            eq = "dump"
        price = EQUIPMENT_PRICES[eq] * hours
        suffix = " (возможны скидки при аренде >20ч)" if hours > 20 else ""
        await bot.api.messages.send(
            peer_id=peer_id,
            random_id=0,
            message=f"Примерная стоимость: {price} руб.{suffix}",
            keyboard=one_button_kb("📝 Заказать", {"cmd": "from_calc_order"}),
        )
        return

    if state == OrderStates.ORDER_NAME:
        if not text:
            await bot.api.messages.send(peer_id=peer_id, random_id=0, message="Введите ваше имя:")
            return
        update_data(user_id, user_name=text)
        set_state(user_id, OrderStates.ORDER_PHONE)
        await bot.api.messages.send(peer_id=peer_id, random_id=0, message="Введите номер телефона для связи:")
        return

    if state == OrderStates.ORDER_PHONE:
        if not PHONE_RE.match(text):
            await bot.api.messages.send(peer_id=peer_id, random_id=0, message="Похоже на неверный формат. Введите номер ещё раз.")
            return
        data = update_data(user_id, user_phone=text)
        if data.get("equipment_type"):
            set_state(user_id, OrderStates.ORDER_HOURS)
            await bot.api.messages.send(peer_id=peer_id, random_id=0, message="На сколько часов нужна техника?")
            return
        set_state(user_id, OrderStates.ORDER_EQUIPMENT_TYPE)
        await bot.api.messages.send(peer_id=peer_id, random_id=0, message="Какую технику нужно арендовать?", keyboard=equipment_choice_kb())
        return

    if state == OrderStates.ORDER_HOURS:
        if not text.isdigit():
            await bot.api.messages.send(peer_id=peer_id, random_id=0, message="Введите целое число часов, например: 8")
            return
        update_data(user_id, hours=int(text))
        set_state(user_id, OrderStates.ORDER_DATE)
        await bot.api.messages.send(peer_id=peer_id, random_id=0, message="Укажите желаемую дату и время (например: 25.05.2026 14:00)")
        return

    if state == OrderStates.ORDER_DATE:
        try:
            datetime.strptime(text, "%d.%m.%Y %H:%M")
        except ValueError:
            await bot.api.messages.send(peer_id=peer_id, random_id=0, message="Формат даты: ДД.ММ.ГГГГ ЧЧ:ММ, например: 25.05.2026 14:00")
            return
        data = update_data(user_id, date=text)
        set_state(user_id, OrderStates.ORDER_FINAL)
        await bot.api.messages.send(peer_id=peer_id, random_id=0, message=order_summary(data), keyboard=order_final_kb())
        return

    await bot.api.messages.send(peer_id=peer_id, random_id=0, message="Используйте /start для меню или /help для справки.")


def validate_config() -> None:
    if not VK_BOT_TOKEN:
        raise RuntimeError("Укажите VK_BOT_TOKEN в переменных окружения.")
    if GROUP_ID == 0:
        logging.warning("GROUP_ID не задан. Для Long Poll чаще всего нужен корректный ID сообщества.")


if __name__ == "__main__":
    validate_config()
    bot.run_forever()
