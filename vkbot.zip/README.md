# VK Bot для аренды спецтехники

Полная реализация под ВКонтакте (`vkbottle` + SQLite) с FSM-сценарием заявок, выбором навесного и админ-командами.

## 1. Установка

```powershell
cd C:\codex\vkbot
python -m venv .venv
.venv\Scripts\Activate.ps1
pip install -r requirements.txt
```

## 2. Переменные окружения

```powershell
$env:VK_BOT_TOKEN="vk1.a.xxxxx"
$env:GROUP_ID="123456789"
$env:ADMIN_PEER_ID="2000000001"
$env:DB_PATH="vkbot.db"
```

- `VK_BOT_TOKEN`: ключ сообщества VK (раздел "Работа с API")
- `GROUP_ID`: ID сообщества
- `ADMIN_PEER_ID`: куда отправлять уведомления о заявках
  - для ЛС админу обычно `peer_id = id_пользователя`
  - для беседы: `2000000000 + chat_id`

Можно также использовать файл `.env` в корне проекта (поддержка уже включена).

## 3. Запуск

```powershell
python bot.py
```

## 4. Фото техники

Сейчас используются локальные файлы:

- `C:\codex\фото\traktor.jpg`
- `C:\codex\фото\kran_2.jpg`
- `C:\codex\фото\samosval 3.jpg`

При необходимости замените пути в `bot.py`:
- `EXCAVATOR_PHOTOS`
- `CRANE_PHOTOS`
- `DUMP_PHOTOS`

## 5. Команды

- `/start`
- `/status <id>`
- `/help`
- `/admin`
- `/admin_stats`
- `/admin_list`
- `/admin_view <id>`
- `/admin_confirm <id>`
- `/admin_done <id>`
- `/admin_delete <id>`
