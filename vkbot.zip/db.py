import json
import sqlite3
from typing import Any


class Database:
    def __init__(self, db_path: str):
        self.db_path = db_path
        self._init_db()

    def _connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        return conn

    def _init_db(self) -> None:
        conn = self._connect()
        cur = conn.cursor()
        cur.execute(
            """
            CREATE TABLE IF NOT EXISTS orders (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                user_name TEXT,
                user_phone TEXT,
                equipment_type TEXT,
                attachments TEXT,
                hours INTEGER,
                date TEXT,
                status TEXT DEFAULT 'new',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
            """
        )
        cur.execute(
            """
            CREATE TABLE IF NOT EXISTS users (
                user_id INTEGER PRIMARY KEY,
                username TEXT,
                full_name TEXT,
                first_seen TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
            """
        )
        cur.execute(
            """
            CREATE TABLE IF NOT EXISTS admin_log (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                admin_id INTEGER,
                action TEXT,
                order_id INTEGER,
                timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
            """
        )
        conn.commit()
        conn.close()

    def save_user(self, user_id: int, username: str | None, full_name: str) -> None:
        conn = self._connect()
        cur = conn.cursor()
        cur.execute(
            """
            INSERT INTO users (user_id, username, full_name)
            VALUES (?, ?, ?)
            ON CONFLICT(user_id) DO UPDATE SET
                username = excluded.username,
                full_name = excluded.full_name
            """,
            (user_id, username, full_name),
        )
        conn.commit()
        conn.close()

    def create_order(self, data: dict[str, Any]) -> int:
        attachments = data.get("attachments")
        attachments_json = json.dumps(attachments, ensure_ascii=False) if attachments else None
        conn = self._connect()
        cur = conn.cursor()
        cur.execute(
            """
            INSERT INTO orders (
                user_id, user_name, user_phone, equipment_type, attachments, hours, date, status
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                data.get("user_id"),
                data.get("user_name"),
                data.get("user_phone"),
                data.get("equipment_type"),
                attachments_json,
                data.get("hours"),
                data.get("date"),
                "new",
            ),
        )
        order_id = cur.lastrowid
        conn.commit()
        conn.close()
        return int(order_id)

    def get_order(self, order_id: int) -> dict[str, Any] | None:
        conn = self._connect()
        cur = conn.cursor()
        cur.execute("SELECT * FROM orders WHERE id = ?", (order_id,))
        row = cur.fetchone()
        conn.close()
        if not row:
            return None
        result = dict(row)
        if result.get("attachments"):
            result["attachments"] = json.loads(result["attachments"])
        return result

    def update_order_status(self, order_id: int, status: str) -> bool:
        conn = self._connect()
        cur = conn.cursor()
        cur.execute("UPDATE orders SET status = ? WHERE id = ?", (status, order_id))
        updated = cur.rowcount > 0
        conn.commit()
        conn.close()
        return updated

    def delete_order(self, order_id: int) -> bool:
        conn = self._connect()
        cur = conn.cursor()
        cur.execute("DELETE FROM orders WHERE id = ?", (order_id,))
        deleted = cur.rowcount > 0
        conn.commit()
        conn.close()
        return deleted

    def orders_stats(self) -> dict[str, int]:
        conn = self._connect()
        cur = conn.cursor()
        cur.execute(
            """
            SELECT
                SUM(CASE WHEN status = 'new' THEN 1 ELSE 0 END) AS new_count,
                SUM(CASE WHEN status = 'confirmed' THEN 1 ELSE 0 END) AS confirmed_count,
                SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) AS completed_count,
                SUM(CASE WHEN status = 'cancelled' THEN 1 ELSE 0 END) AS cancelled_count,
                COUNT(*) AS total_count
            FROM orders
            """
        )
        row = cur.fetchone()
        conn.close()
        return {
            "new": int(row["new_count"] or 0),
            "confirmed": int(row["confirmed_count"] or 0),
            "completed": int(row["completed_count"] or 0),
            "cancelled": int(row["cancelled_count"] or 0),
            "total": int(row["total_count"] or 0),
        }

    def list_orders(self, limit: int = 30) -> list[dict[str, Any]]:
        conn = self._connect()
        cur = conn.cursor()
        cur.execute(
            "SELECT id, user_name, equipment_type, status, created_at FROM orders ORDER BY id DESC LIMIT ?",
            (limit,),
        )
        rows = cur.fetchall()
        conn.close()
        return [dict(r) for r in rows]

    def log_admin_action(self, admin_id: int, action: str, order_id: int | None = None) -> None:
        conn = self._connect()
        cur = conn.cursor()
        cur.execute(
            "INSERT INTO admin_log (admin_id, action, order_id) VALUES (?, ?, ?)",
            (admin_id, action, order_id),
        )
        conn.commit()
        conn.close()
